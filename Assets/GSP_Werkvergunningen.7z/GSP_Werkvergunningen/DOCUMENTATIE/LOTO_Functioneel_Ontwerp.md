# LOTO (Lock-Out Tag-Out) Functioneel Ontwerp

## 1. Algemene LOTO-informatie

### Doel
Het LOTO-onderdeel biedt een complete digitale procedure voor het veilig isoleren en vergrendelen van energiebronnen tijdens onderhoud, reparatie of inspectie van machines en installaties.

### Verplichtingen
- **NEN-EN-ISO 14118:** Veiligheid van machines - Voorkoming van onverwachte start
- **OSHA 29 CFR 1910.147:** The Control of Hazardous Energy (Lockout/Tagout)
- **Interne procedures:** Bedrijfsveiligheidshandboek

### Functionaliteit
- Informatieve sectie met uitleg over LOTO-procedures
- Verwijzingen naar relevante normen en procedures
- Duidelijke waarschuwingen over het belang van LOTO

---

## 2. Installatie- en werkidentificatie

### Datavelden

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `installatie_naam` | Text | Ja | Min. 2 karakters | Naam van de installatie of machine |
| `installatie_id` | Text | Ja | Uniek, alfanumeriek | Uniek identificatienummer van de installatie |
| `locatie` | Text | Ja | Min. 2 karakters | Fysieke locatie van de installatie |
| `werkvergunningnummer` | Text | Ja | Alfanumeriek | Nummer van de werkvergunning |
| `loto_datum` | Date | Ja | Geldige datum | Datum waarop LOTO wordt geactiveerd |
| `loto_tijd` | Time | Ja | Geldige tijd | Tijd waarop LOTO wordt geactiveerd |

### Validatieregels
- Alle velden zijn verplicht
- `installatie_id` moet uniek zijn binnen het systeem
- `loto_datum` mag niet in het verleden liggen (tenzij voor historische registratie)
- `loto_tijd` moet binnen werkuren vallen (configuratie optioneel)

---

## 3. Energiebronnen

### Selecteerbare energiebronnen

| Energiebron | ID | Icoon | Beschrijving |
|-------------|-----|-------|--------------|
| Elektrisch | `elektrisch` | ⚡ power | Elektrische energie |
| Mechanisch | `mechanisch` | ⚙️ settings | Mechanische energie (beweging, rotatie) |
| Hydraulisch | `hydraulisch` | 💧 water_drop | Hydraulische druk |
| Pneumatisch | `pneumatisch` | 💨 air | Luchtdruk |
| Chemisch | `chemisch` | 🧪 science | Chemische energie |
| Thermisch | `thermisch` | 🔥 local_fire_department | Warmte, stoom |

### Overige energiebronnen
- Vrij tekstveld voor niet-standaard energiebronnen
- Optioneel veld

### Validatieregels
- Minimaal één energiebron moet worden geselecteerd
- Bij selectie van energiebron worden automatisch detailvelden gegenereerd

---

## 4. LOTO-maatregelen per energiebron

### Datavelden per energiebron

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `isolatie_[energie]` | Text | Ja | Min. 5 karakters | Methode van isolatie (bijv. "Hoofdschakelaar uit") |
| `vergrendeling_[energie]` | Text | Ja | Min. 5 karakters | Methode van vergrendeling (bijv. "Slot op schakelaar") |
| `restenergie_[energie]` | Select | Ja | Ja/Nee | Is restenergie afgelaten? |
| `restenergie_toelichting_[energie]` | Textarea | Voorwaardelijk | Min. 10 karakters | Toelichting indien restenergie is afgelaten |
| `spanningsloos_[energie]` | Checkbox | Ja | - | Controle op spanningsloosheid uitgevoerd |

### Validatieregels
- Alle velden zijn verplicht voor elke geselecteerde energiebron
- `restenergie_toelichting` is alleen verplicht indien `restenergie` = "Ja"
- `spanningsloos` checkbox moet worden aangevinkt

### Dynamische generatie
- Detailvelden worden automatisch gegenereerd bij selectie van energiebron
- Velden worden verwijderd bij deselectie van energiebron

---

## 5. Slot- en tagregistratie

### Datavelden

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `aantal_sloten` | Number | Ja | Min. 1, Max. 50 | Aantal geplaatste sloten |
| `slotnummer_[i]` | Text | Ja | Uniek, alfanumeriek | Uniek nummer van elk slot |
| `tagnummer_[i]` | Text | Ja | Uniek, alfanumeriek | Uniek nummer van elke tag |
| `slot_eigenaar_[i]` | Text | Ja | Min. 2 karakters | Naam van persoon die slot plaatste |
| `loto_foto` | File | Optioneel | Image/*, Max. 10MB | Foto's van aangebrachte LOTO |

### Validatieregels
- `aantal_sloten` moet minimaal 1 zijn
- Elk slot moet een uniek `slotnummer` hebben
- Elk slot moet een uniek `tagnummer` hebben
- Foto's zijn optioneel maar aanbevolen voor audit-doeleinden
- Maximaal 10 foto's per LOTO-procedure

### Dynamische generatie
- Slotregistratievelden worden automatisch gegenereerd op basis van `aantal_sloten`
- Elke slot krijgt een eigen sectie met verplichte velden

---

## 6. Betrokken personen

### Uitvoerder(s)

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `uitvoerder_naam[]` | Text | Ja | Min. 2 karakters | Naam van uitvoerder |
| `uitvoerder_email[]` | Email | Ja | Geldig e-mailadres | E-mailadres van uitvoerder |
| `uitvoerder_tel[]` | Tel | Ja | Geldig telefoonnummer | Telefoonnummer van uitvoerder |

### LOTO-verantwoordelijke

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `loto_verantwoordelijke_naam` | Text | Ja | Min. 2 karakters | Naam van LOTO-verantwoordelijke |
| `loto_verantwoordelijke_email` | Email | Ja | Geldig e-mailadres | E-mailadres |
| `loto_verantwoordelijke_tel` | Tel | Ja | Geldig telefoonnummer | Telefoonnummer |

### Toezichthouder / WV-verstrekker

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `toezichthouder_naam` | Text | Ja | Min. 2 karakters | Naam van toezichthouder |
| `toezichthouder_email` | Email | Ja | Geldig e-mailadres | E-mailadres |
| `toezichthouder_tel` | Tel | Ja | Geldig telefoonnummer | Telefoonnummer |

### Validatieregels
- Minimaal één uitvoerder is verplicht
- E-mailadressen moeten geldig zijn (regex validatie)
- Telefoonnummers moeten geldig zijn (formaat: +32 of 0 gevolgd door 9 cijfers)
- Contactgegevens zijn alleen intern zichtbaar (rolgebaseerde toegang)

### Functionaliteit
- Dynamisch toevoegen/verwijderen van uitvoerders
- Minimaal één uitvoerder moet aanwezig blijven

---

## 7. Checklist vóór start werk

### Checklist items

| Item | ID | Verplicht | Beschrijving |
|------|-----|-----------|--------------|
| Alle energiebronnen geïsoleerd | `check_energiebronnen` | Ja | Bevestiging dat alle energiebronnen zijn geïsoleerd |
| Alle sloten geplaatst | `check_sloten` | Ja | Bevestiging dat alle sloten correct zijn geplaatst |
| Tags correct ingevuld | `check_tags` | Ja | Bevestiging dat tags correct zijn ingevuld en bevestigd |
| Werkplek gecontroleerd | `check_werkplek` | Ja | Bevestiging dat werkplek is gecontroleerd op veiligheid |
| Iedereen geïnformeerd | `check_informeren` | Ja | Bevestiging dat iedereen is geïnformeerd over LOTO-procedure |

### Validatieregels
- Alle checklist items moeten worden aangevinkt voordat werkvergunning kan worden goedgekeurd
- Checklist items kunnen niet worden overgeslagen
- Validatie vindt plaats bij verzenden van formulier

---

## 8. Vrijgave en opheffen LOTO

### Voorwaarden voor vrijgave

| Item | ID | Verplicht | Beschrijving |
|------|-----|-----------|--------------|
| Werkzaamheden afgerond | `vrijgave_werkzaamheden` | Ja | Bevestiging dat alle werkzaamheden zijn afgerond |
| Personen uit gevarenzone | `vrijgave_personen` | Ja | Bevestiging dat alle personen uit gevarenzone zijn |
| Gereedschap verwijderd | `vrijgave_gereedschap` | Ja | Bevestiging dat gereedschap en materialen zijn verwijderd |
| Veiligheidsmaatregelen verwijderd | `vrijgave_veiligheidsmaatregelen` | Ja | Bevestiging dat tijdelijke veiligheidsmaatregelen zijn verwijderd |

### Datavelden

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `volgorde_verwijderen` | Textarea | Ja | Min. 10 karakters | Beschrijving van volgorde waarin sloten moeten worden verwijderd |
| `opheffen_datum` | Date | Optioneel | Geldige datum | Datum waarop LOTO wordt opgeheven |
| `opheffen_tijd` | Time | Optioneel | Geldige tijd | Tijd waarop LOTO wordt opgeheven |

### Validatieregels
- Alle vrijgave-checklist items moeten worden aangevinkt
- `volgorde_verwijderen` is verplicht en moet minimaal 10 karakters bevatten
- `opheffen_datum` en `opheffen_tijd` zijn optioneel maar worden automatisch ingevuld bij opheffen

---

## 9. Digitale ondertekening

### Handtekeningen

| Handtekening | Canvas ID | Verplicht | Beschrijving |
|--------------|-----------|-----------|--------------|
| Uitvoerder | `signature_uitvoerder` | Ja | Handtekening van uitvoerder |
| LOTO-verantwoordelijke | `signature_loto` | Ja | Handtekening van LOTO-verantwoordelijke |
| Werkvergunningverstrekker | `signature_wv` | Ja | Handtekening van werkvergunningverstrekker |

### Datavelden per handtekening

| Veld | Type | Verplicht | Validatie | Beschrijving |
|------|------|-----------|-----------|--------------|
| `[rol]_naam_handtekening` | Text | Ja | Min. 2 karakters | Naam van ondertekenaar |
| `[rol]_datum_handtekening` | DateTime | Automatisch | - | Datum en tijd van ondertekening (automatisch) |

### Validatieregels
- Alle drie handtekeningen zijn verplicht
- Handtekening moet daadwerkelijk getekend zijn (canvas niet leeg)
- Naam van ondertekenaar is verplicht
- Datum/tijd wordt automatisch vastgelegd bij tekenen

### Functionaliteit
- Canvas-gebaseerde handtekening (touch en mouse support)
- Mogelijkheid om handtekening te wissen en opnieuw te tekenen
- Handtekening wordt opgeslagen als base64 PNG afbeelding
- Automatische timestamp bij ondertekening

---

## 10. Logging & Compliance

### Audit Trail

Elke actie wordt automatisch gelogd met:

| Veld | Type | Beschrijving |
|------|------|-------------|
| `timestamp` | DateTime | ISO 8601 timestamp |
| `action` | Text | Beschrijving van actie |
| `details` | Text | Aanvullende details |
| `user` | Text | E-mailadres van gebruiker |

### Gelogde acties

- Energiebronnen bijgewerkt
- Slot registratie bijgewerkt
- Uitvoerder toegevoegd/verwijderd
- Foto's geüpload/verwijderd
- Handtekening gezet/gewist
- LOTO opgeslagen
- LOTO verzonden

### Compliance Features

- **Onwijzigbare tijdstempels:** Timestamps worden server-side gegenereerd (in productie)
- **Audit trail:** Volledige geschiedenis van alle wijzigingen
- **Digitale handtekeningen:** Cryptografisch beveiligde handtekeningen (in productie)
- **Export functionaliteit:** PDF export van volledige LOTO-procedure
- **Opslag:** Data wordt opgeslagen in werkvergunninghistorie

### Export

- PDF export met alle LOTO-gegevens
- Inclusief handtekeningen, foto's en audit trail
- Watermark en timestamp op PDF

---

## 11. UX / UI Eisen

### Overzichtelijke secties
- Duidelijke visuele scheiding tussen secties
- Gebruik van iconen voor snelle herkenning
- Collapsible secties voor lange formulieren (optioneel)

### Iconen (Google Material Symbols)
- ⚡ `power` - Elektrisch
- ⚙️ `settings` - Mechanisch
- 💧 `water_drop` - Hydraulisch
- 💨 `air` - Pneumatisch
- 🧪 `science` - Chemisch
- 🔥 `local_fire_department` - Thermisch
- 🔒 `lock` - Slot/Tag
- ✅ `check_circle` - Checklist
- 🔓 `lock_open` - Vrijgave
- ✍️ `draw` - Handtekening
- 📋 `checklist` - Checklist
- 📸 `photo_camera` - Foto
- 👥 `people` - Personen
- ℹ️ `info` - Informatie
- ⚠️ `warning` - Waarschuwing

### Validatie
- Real-time validatie bij blur events
- Visuele feedback (rood voor fouten, groen voor correct)
- Werkvergunning kan niet worden goedgekeurd zonder complete LOTO
- Duidelijke foutmeldingen met iconen

### Responsive Design
- Mobiel-vriendelijk (touch support voor handtekeningen)
- Tablet-optimized layout
- Desktop volledig functioneel
- Flexibele grid layouts die zich aanpassen aan schermgrootte

---

## 12. Technisch

### Integratie
- Geschikt voor integratie in bestaande webapp
- Gebruikt bestaande CSS base (`werkvergunning-base.css`)
- Volgt bestaande HTML structuur en naming conventions
- Compatibel met bestaande JavaScript functionaliteit

### Rol- en rechtenstructuur

| Rol | Rechten |
|-----|---------|
| Leerling/Externe | Kan LOTO invullen, niet goedkeuren |
| Leerkracht | Kan LOTO invullen en bekijken |
| TA | Kan LOTO invullen, goedkeuren en opheffen |
| Directeur | Volledige toegang, kan alle LOTO's bekijken en exporteren |

### API-ready
- Data structuur is JSON-compatibel
- Functies voor serialisatie/deserialisatie aanwezig
- Klaar voor REST API integratie
- Endpoints voorzien:
  - `POST /api/loto` - Nieuwe LOTO aanmaken
  - `GET /api/loto/:id` - LOTO ophalen
  - `PUT /api/loto/:id` - LOTO bijwerken
  - `DELETE /api/loto/:id` - LOTO verwijderen
  - `GET /api/loto/:id/pdf` - PDF export

### Meertaligheid
- Ondersteuning voor Nederlands (NL) en Engels (EN)
- Language switcher in header (toekomstige uitbreiding)
- Alle teksten via translation keys (toekomstige uitbreiding)

### Browser Compatibiliteit
- Chrome/Edge (laatste 2 versies)
- Firefox (laatste 2 versies)
- Safari (laatste 2 versies)
- Mobile browsers (iOS Safari, Chrome Mobile)

---

## Datamodel

### LOTO Object Structuur

```json
{
  "id": "string",
  "werkvergunningnummer": "string",
  "installatie_naam": "string",
  "installatie_id": "string",
  "locatie": "string",
  "loto_datum": "YYYY-MM-DD",
  "loto_tijd": "HH:mm",
  "energiebronnen": ["elektrisch", "mechanisch", ...],
  "energie_overige": "string",
  "energiebronnen_details": {
    "elektrisch": {
      "isolatie": "string",
      "vergrendeling": "string",
      "restenergie": "ja|nee",
      "restenergie_toelichting": "string",
      "spanningsloos": true
    }
  },
  "aantal_sloten": 3,
  "sloten": [
    {
      "slotnummer": "SL-001",
      "tagnummer": "TAG-001",
      "eigenaar": "string"
    }
  ],
  "foto's": ["base64", ...],
  "uitvoerders": [
    {
      "naam": "string",
      "email": "string",
      "telefoon": "string"
    }
  ],
  "loto_verantwoordelijke": {
    "naam": "string",
    "email": "string",
    "telefoon": "string"
  },
  "toezichthouder": {
    "naam": "string",
    "email": "string",
    "telefoon": "string"
  },
  "checklist": ["energiebronnen", "sloten", ...],
  "vrijgave_checklist": ["werkzaamheden", "personen", ...],
  "volgorde_verwijderen": "string",
  "opheffen_datum": "YYYY-MM-DD",
  "opheffen_tijd": "HH:mm",
  "handtekeningen": {
    "uitvoerder": "base64",
    "loto": "base64",
    "wv": "base64"
  },
  "handtekening_gegevens": {
    "uitvoerder_naam": "string",
    "uitvoerder_datum": "ISO 8601",
    "loto_naam": "string",
    "loto_datum": "ISO 8601",
    "wv_naam": "string",
    "wv_datum": "ISO 8601"
  },
  "audit_trail": [
    {
      "timestamp": "ISO 8601",
      "action": "string",
      "details": "string",
      "user": "string"
    }
  ],
  "status": "concept|ingediend|goedgekeurd|opgeheven",
  "created_at": "ISO 8601",
  "updated_at": "ISO 8601",
  "submitted_at": "ISO 8601"
}
```

---

## Validatie Overzicht

### Client-side Validatie
- HTML5 form validatie (required, type, pattern)
- JavaScript custom validatie
- Real-time feedback bij blur events
- Visuele indicatoren (rood/groen borders)

### Server-side Validatie (toekomstig)
- Alle client-side validaties opnieuw controleren
- Uniciteit controles (installatie_id, slotnummers)
- Gebruikersrechten verificatie
- Data integriteit controles

### Validatie Prioriteiten
1. **Kritiek:** Zonder deze velden kan LOTO niet worden verzonden
2. **Belangrijk:** Aanbevolen maar niet verplicht
3. **Optioneel:** Extra informatie voor audit-doeleinden

---

## Beveiliging

### Data Beveiliging
- Sensitieve gegevens (contactgegevens) alleen intern zichtbaar
- Handtekeningen cryptografisch beveiligd (in productie)
- Audit trail onwijzigbaar na creatie
- HTTPS verplicht voor alle communicatie

### Toegangscontrole
- Rolgebaseerde toegang (RBAC)
- Session management
- CSRF protection (in productie)
- XSS protection (input sanitization)

---

## Toekomstige Uitbreidingen

1. **Notificaties:** E-mail/SMS notificaties bij belangrijke events
2. **Workflow:** Multi-step approval proces
3. **Integratie:** Koppeling met CMMS systemen
4. **Analytics:** Dashboard met LOTO statistieken
5. **Mobile App:** Native mobile app voor LOTO procedures
6. **QR Codes:** QR codes voor snelle identificatie van sloten/tags
7. **NFC Tags:** NFC ondersteuning voor sloten/tags
8. **Real-time Tracking:** Live tracking van LOTO status

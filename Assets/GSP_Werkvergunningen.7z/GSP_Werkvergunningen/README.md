# GSP_Werkvergunningen
index.html = inlogpagina
overzicht.html = het overzicht aangepast aan de rol van de gebruiker
werkvergunning.html = voor het aanmaken voor een werkvergunning
lototovergunning.html = het veiligstellen van de werkplek


document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('registrationForm');
            const qtySlider = document.getElementById('ticketQuantity');
            const qtyDisplay = document.getElementById('quantityDisplay');
            const totalPriceDisplay = document.getElementById('totalPrice');
            const promoBtn = document.getElementById('btnApplyPromo');
            const promoInput = document.getElementById('promoCode');
            const promoFeedback = document.getElementById('promoFeedback');
            const tshirtSection = document.getElementById('tshirtSection');
            const workshopCbs = document.querySelectorAll('.workshop-cb');
            const ticketRadios = document.getElementsByName('ticketType');

            let isDiscountApplied = false;

            // --- 1. Countdown Timer ---
            const targetDate = new Date('May 15, 2026 09:00:00').getTime();
            function updateClock() {
                const now = new Date().getTime();
                const d = targetDate - now;
                document.getElementById('days').innerText = Math.floor(d / 86400000).toString().padStart(2, '0');
                document.getElementById('hours').innerText = Math.floor((d % 86400000) / 3600000).toString().padStart(2, '0');
                document.getElementById('minutes').innerText = Math.floor((d % 3600000) / 60000).toString().padStart(2, '0');
                document.getElementById('seconds').innerText = Math.floor((d % 60000) / 1000).toString().padStart(2, '0');
            }
            setInterval(updateClock, 1000);
            updateClock();

            // --- 2. Prijsberekening Functie ---
            function calculateTotal() {
                // Vind geselecteerde ticket
                let selectedPrice = 0;
                let isVIP = false;
                ticketRadios.forEach(r => {
                    if(r.checked) {
                        selectedPrice = parseFloat(r.dataset.price);
                        if(r.value === 'VIP') isVIP = true;
                    }
                });

                // Update UI voor VIP veld
                tshirtSection.style.display = isVIP ? 'block' : 'none';

                // Aantal en Workshops
                const qty = parseInt(qtySlider.value);
                const workshopsPrice = Array.from(workshopCbs).filter(cb => cb.checked).length * 50;

                // Berekening
                let total = (selectedPrice * qty) + workshopsPrice;
                if(isDiscountApplied) total *= 0.8; // 20% korting

                // Display
                qtyDisplay.innerText = qty;
                totalPriceDisplay.innerText = `€ ${total.toLocaleString('nl-BE', { minimumFractionDigits: 2 })}`;
            }

            // --- 3. Event Listeners voor Prijs ---
            qtySlider.addEventListener('input', calculateTotal);
            ticketRadios.forEach(r => r.addEventListener('change', calculateTotal));
            workshopCbs.forEach(cb => cb.addEventListener('change', (e) => {
                // Max 3 check
                const checked = Array.from(workshopCbs).filter(c => c.checked);
                if(checked.length > 3) {
                    e.target.checked = false;
                    return;
                }
                calculateTotal();
            }));

            // --- 4. Kortingscode Validatie ---
            promoBtn.addEventListener('click', () => {
                const code = promoInput.value.trim().toUpperCase();
                promoFeedback.classList.remove('hidden');
                
                if(code === 'TECH20') {
                    isDiscountApplied = true;
                    promoFeedback.innerText = "✓ Code TECH20 toegepast (-20%)";
                    promoFeedback.className = "text-xs mt-2 text-green-400";
                } else {
                    isDiscountApplied = false;
                    promoFeedback.innerText = "✗ Ongeldige kortingscode";
                    promoFeedback.className = "text-xs mt-2 text-red-400";
                }
                calculateTotal();
            });

            // --- 5. Accordion Logica ---
            document.querySelectorAll('.faq-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const panel = btn.nextElementSibling;
                    const icon = btn.querySelector('span:last-child');
                    const isOpen = !panel.classList.contains('hidden');
                    
                    // Sluit anderen
                    document.querySelectorAll('.faq-panel').forEach(p => p.classList.add('hidden'));
                    document.querySelectorAll('.faq-btn span:last-child').forEach(i => i.style.transform = 'rotate(0deg)');

                    if(!isOpen) {
                        panel.classList.remove('hidden');
                        icon.style.transform = 'rotate(45deg)';
                    }
                });
            });

            // --- 6. Formulier Verzenden ---
            form.onsubmit = (e) => {
                e.preventDefault();
                const name = document.getElementById('userName').value;
                
                // Genereer TicketNummer
                const prefix = name.substring(0,3).toUpperCase();
                const ticketID = `${prefix}-${Date.now().toString().slice(-4)}-${Math.floor(1000+Math.random()*9000)}`;
                
                form.classList.add('hidden');
                document.getElementById('confirmationBox').classList.remove('hidden');
                document.getElementById('ticketID').innerText = ticketID;
            };

            // Initiale berekening
            calculateTotal();
        });